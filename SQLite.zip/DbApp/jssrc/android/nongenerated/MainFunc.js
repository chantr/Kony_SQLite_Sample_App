/*****************************************************************
 *	Name    : success_sqlSelect
 *	Author  : Kony Solutions
 *	Purpose : To show all the rows of 'emp_details' table in the form
 ******************************************************************/
function success_sqlSelect(transactionId, resultset) {
    var dataObj1;
    //logic to process the resultset
    for (var i = 0; i < resultset.rows.length; i++) {
        var rowItem = kony.db.sqlResultsetRowItem(transactionId, resultset, i);
        kony.print(" empname:" + rowItem.empname);
        dataObj1 = {
            empID: rowItem.empid,
            empName: rowItem.empname,
            depID: rowItem.depid,
        };
        ListForm.Segment01.addDataAt(dataObj1, i);
    }
}
/*****************************************************************
 *	Name    : success_dropTable
 *	Author  : Kony Solutions
 *	Purpose : To display a message on the console when table creation is unsuccessful.
 ******************************************************************/
function success_dropTable(transactionId, resultset) {
    kony.print("Table was dropped");
}
/*****************************************************************
 *	Name    : success_createTable
 *	Author  : Kony Solutions
 *	Purpose : To display a message when table creation is successful.
 ******************************************************************/
function success_createTable(transactionId, resultset) {
    kony.print("Table is created successfully");
}

function success_insertTable(transactionId, resultset) {
    kony.print("Insert is done successfully");
}
/*****************************************************************
 *	Name    : commonErrorCallback
 *	Author  : Kony Solutions
 *	Purpose : To display error message on the console 
 ******************************************************************/
function commonErrorCallback(transactionId, error) {
    kony.print(" Error code:: " + error);
    kony.print(" Error message:: " + error.message);
}
/*****************************************************************
 *	Name    : commonVoidcallback
 *	Author  : Kony Solutions
 *	Purpose : To display success message on the console.
 ******************************************************************/
function commonVoidcallback() {
    kony.print("The transaction was executed successfully.");
}
/*****************************************************************kony.db.openDatabase
 *	Name    : createTable
 *	Author  : Kony Solutions
 *	Purpose : To create emp_details table with 4 rows
 ******************************************************************/
function createTable(dbId) {
    var sqlStatement = "DROP TABLE IF EXISTS emp_details";
    kony.db.executeSql(dbId, sqlStatement, null, success_dropTable, commonErrorCallback);
    var sqlStatement = "CREATE TABLE IF NOT EXISTS emp_details (empid REAL PRIMARY KEY,empname TEXT,depid REAL)";
    kony.db.executeSql(dbId, sqlStatement, null, success_createTable, commonErrorCallback);
}
/*****************************************************************
 *	Name    : transaction
 *	Author  : Kony Solutions
 *	Purpose : To open a transaction on click of Add button.
 ******************************************************************/
function transaction() {
    baseObjectId = kony.db.openDatabase("webSqlDB", "1.0", "Sample SQL Database", 5 * 1024 * 1024);
    kony.db.transaction(baseObjectId, insertTable, commonErrorCallback, commonVoidcallback);
}
/*****************************************************************
 *	Name    : insertTable
 *	Author  : Kony Solutions
 *	Purpose : To insert row in the table
 ******************************************************************/
function insertTable(dbId) {
    var empID = MainForm.IDTextBox.text;
    var empName = MainForm.NameTextBox.text;
    var depID = MainForm.DepartmentTextBox.text;
    var sqlStatement = "INSERT INTO emp_details VALUES (" + empID + ",\"" + empName + "\"," + depID + ")";
    kony.db.executeSql(dbId, sqlStatement, null, success_insertTable, commonErrorCallback);
    var sqlStatement = "SELECT * FROM emp_details";
    kony.db.executeSql(dbId, sqlStatement, null, success_sqlSelect, commonErrorCallback);
    ListForm.show();
}
/*****************************************************************
 *	Name    : createDB
 *	Author  : Kony Solutions
 *	Purpose : To create the database with employee_details table
 ******************************************************************/
function createDB() {
    webSQLFlag = 1;
    baseObjectId = kony.db.openDatabase("webSqlDB", "1.0", "Sample SQL Database", 5 * 1024 * 1024); // 5MB database
    kony.db.transaction(baseObjectId, createTable, commonErrorCallback, commonVoidcallback);
}