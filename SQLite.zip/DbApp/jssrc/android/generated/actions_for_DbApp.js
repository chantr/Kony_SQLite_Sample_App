//actions.js file 
function AS_Button_7b9b7e158cef405c922df8b5b3019cad(eventobject) {
    MainForm.show();
}
function AS_Button_ba468f239c7d4206a51e7b064cc4f7d7(eventobject) {
    MainForm.show();
}
function AS_Button_f6ecd51287f4454a95e30a9cd7a21845(eventobject) {
    return transaction.call(this);
}
function AS_Form_4379b36565784d28b582be30be15120e(eventobject) {
    return createDB.call(this);
}
function AS_Form_9b1dca07755a41028637868153054674(eventobject) {}