function addWidgetsListForm() {
    ListForm.setDefaultUnit(kony.flex.DP);
    var FlexContainer08b45d9671a2645 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "551dp",
        "id": "FlexContainer08b45d9671a2645",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox0e7e37380fabc4f",
        "top": "0dp",
        "width": "99.96%"
    }, {}, {});
    FlexContainer08b45d9671a2645.setDefaultUnit(kony.flex.DP);
    var Segment01 = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "depID": "",
            "empID": "",
            "empName": ""
        }],
        "groupCells": false,
        "height": "120dp",
        "id": "Segment01",
        "isVisible": true,
        "left": "2dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageOffDot.png",
        "pageOnDotImage": "pageOnDot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": Flex01,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "fffcff00",
        "separatorRequired": true,
        "separatorThickness": 0,
        "showScrollbars": false,
        "top": "65dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "Flex01": "Flex01",
            "depID": "depID",
            "empID": "empID",
            "empName": "empName"
        },
        "width": "100%"
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var EmpID = new kony.ui.Label({
        "id": "EmpID",
        "isVisible": true,
        "left": "2dp",
        "skin": "CopyslLabel0276ad58f654a42",
        "text": "EmpID",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "32dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var EmpName = new kony.ui.Label({
        "id": "EmpName",
        "isVisible": true,
        "left": "117dp",
        "skin": "CopyslLabel064462b78cc9845",
        "text": "Name",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "32dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var DepId = new kony.ui.Label({
        "id": "DepId",
        "isVisible": true,
        "left": "280dp",
        "skin": "CopyslLabel04a27cf46ce0946",
        "text": "DepId",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "32dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Back = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "Back",
        "isVisible": true,
        "left": "41dp",
        "onClick": AS_Button_7b9b7e158cef405c922df8b5b3019cad,
        "skin": "slButtonGlossBlue",
        "text": "Back",
        "top": "399dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer08b45d9671a2645.add(
    Segment01, EmpID, EmpName, DepId, Back);
    ListForm.add(
    FlexContainer08b45d9671a2645);
};

function ListFormGlobals() {
    ListForm = new kony.ui.Form2({
        "addWidgets": addWidgetsListForm,
        "enabledForIdleTimeout": false,
        "id": "ListForm",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "skin": "slForm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "footerOverlap": false,
        "headerOverlap": false,
        "menuPosition": constants.FORM_MENU_POSITION_AFTER_APPMENU,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarSkin": "slTitleBar",
        "windowSoftInputMode": constants.FORM_ADJUST_RESIZE
    });
};